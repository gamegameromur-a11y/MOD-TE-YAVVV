package dev.fix.cc_aero_fix.mixin;

import com.hlysine.create_connected.content.redstonelinkwildcard.LinkWildcardNetworkHandler;
import com.simibubi.create.content.redstone.link.IRedstoneLinkable;
import com.simibubi.create.content.redstone.link.RedstoneLinkNetworkHandler;
import dev.ryanhcode.sable.sublevel.ServerSubLevel;
import net.minecraft.world.level.LevelAccessor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Fixes Create: Connected × Create: Aeronautics (Sable SubLevel) incompatibility.
 *
 * Problem:
 *   RedstoneLinkNetworkHandlerMixin (Create: Connected, priority 2000) injects at
 *   HEAD of RedstoneLinkNetworkHandler#updateNetworkOf and calls
 *   LinkWildcardNetworkHandler.updateNetworkOf(). If that returns true it calls
 *   ci.cancel(), permanently bypassing the original Create network logic.
 *
 *   Sable's ServerSubLevel instances are NEVER added to LinkWildcardNetworkHandler's
 *   internal maps (transmitter_connections / receiver_connections) because SubLevels
 *   do not fire LevelEvent.Load / LevelEvent.Unload. As a result:
 *     1. transmittersIn(subLevel) logs a warning and returns an empty map.
 *     2. updateNetworkOf() still returns true → ci.cancel() fires.
 *     3. The original Create redstone-link logic is skipped inside contraptions.
 *
 * Fix:
 *   Inject into LinkWildcardNetworkHandler.updateNetworkOf() at HEAD. When the
 *   LevelAccessor is a Sable ServerSubLevel, immediately return false.
 *   RedstoneLinkNetworkHandlerMixin then receives false, does NOT call ci.cancel(),
 *   and the original RedstoneLinkNetworkHandler.updateNetworkOf() runs normally —
 *   restoring full redstone-link functionality inside physics contraptions.
 *
 * This mixin targets a non-Minecraft class, so remap = false.
 */
@Mixin(value = LinkWildcardNetworkHandler.class, remap = false)
public class LinkWildcardNetworkHandlerFixMixin {

    /**
     * When the world passed to updateNetworkOf is a Sable ServerSubLevel,
     * skip the wildcard handler entirely and let vanilla Create handle it.
     */
    @Inject(
            method = "updateNetworkOf(Lcom/simibubi/create/content/redstone/link/RedstoneLinkNetworkHandler;Lnet/minecraft/world/level/LevelAccessor;Lcom/simibubi/create/content/redstone/link/IRedstoneLinkable;)Z",
            at = @At("HEAD"),
            cancellable = true,
            remap = false
    )
    private static void cc_aero_fix$skipSubLevel(
            RedstoneLinkNetworkHandler handler,
            LevelAccessor world,
            IRedstoneLinkable actor,
            CallbackInfoReturnable<Boolean> cir
    ) {
        if (world instanceof ServerSubLevel) {
            // Return false → RedstoneLinkNetworkHandlerMixin will NOT call ci.cancel()
            // → Original RedstoneLinkNetworkHandler.updateNetworkOf() proceeds normally.
            cir.setReturnValue(false);
        }
    }
}
