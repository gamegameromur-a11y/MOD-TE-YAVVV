package dev.fix.cc_aero_fix;

import net.neoforged.fml.common.Mod;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Create Connected Aeronautics FIX
 *
 * Fixes the incompatibility between Create: Connected and Create: Aeronautics (via Sable).
 *
 * Root Cause:
 *   RedstoneLinkNetworkHandlerMixin (Create: Connected, priority 2000) always calls
 *   LinkWildcardNetworkHandler.updateNetworkOf() and cancels the original method when
 *   it returns true. However, Sable SubLevel worlds are never registered in
 *   LinkWildcardNetworkHandler's transmitter_connections / receiver_connections maps
 *   (SubLevels don't fire standard LevelEvent.Load). This causes the original Create
 *   redstone-link logic to be bypassed entirely inside physics contraptions.
 *
 * Fix Applied (LinkWildcardNetworkHandlerFixMixin):
 *   Injects into LinkWildcardNetworkHandler.updateNetworkOf() at HEAD. When the world
 *   is a Sable ServerSubLevel, immediately returns false. This prevents
 *   RedstoneLinkNetworkHandlerMixin from calling ci.cancel(), so the original
 *   RedstoneLinkNetworkHandler.updateNetworkOf() executes normally for contraptions.
 */
@Mod(CCAeroFix.MODID)
public class CCAeroFix {

    public static final String MODID = "cc_aero_fix";
    public static final Logger LOGGER = LoggerFactory.getLogger(MODID);

    public CCAeroFix() {
        LOGGER.info("[CC Aero Fix] Loaded — Create:Connected × Aeronautics SubLevel patch active.");
    }
}
